#include <stdio.h>

int main()
{
	int a, b;
	scanf("%d", &a);
	printf("Hello, %d\n", a);
	return 0;
}
