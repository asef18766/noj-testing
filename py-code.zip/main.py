print('Hello,', input())
