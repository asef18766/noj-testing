#include <iostream>

using namespace std;

int main()
{
	int x;
	while(cin >> x) cout << x << '\n';
	return 0;
}
